﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PZ_2
{
    class Program
    {
        

        static void Main(string[] args)
        {
            bool exit = false;
            WorkWhithFile.ChangeFile changeFile = new WorkWhithFile.ChangeFile();
            WorkWhithFile.WorkWithData wWD;
            string name="";



            do
            {
                Console.Clear();
                string rl;
                Console.WriteLine(" iput W, R ");
                rl = Console.ReadLine();

                if (rl == "W")
                {                      
                    List<string> code = new List<string>();
                    List<string> text = new List<string>();

                    Console.WriteLine(" iput name of the folder");
                    name = Console.ReadLine();

                    code = changeFile.ReadFile("Code//Code",true, false);
                    text = changeFile.ReadFile("text//text",false,false);

                    wWD = new WorkWhithFile.WorkWithData(text,code,name);
                    wWD.CodingData();

                    Console.WriteLine(" it`s done");                    
                }

                else if (rl == "R")
                {
                    wWD = new WorkWhithFile.WorkWithData(name);
                    wWD.DecodingData();
                    Console.WriteLine(" it`s done");
                }

                string l;
                Console.WriteLine("exit e");
                l = Console.ReadLine();
                if (l == "e")
                    exit = true;

            }while(!exit);
           
        }
    }
}
